import Vue from 'vue';
import Router from 'vue-router';
Vue.use(Router);

export default new Router({
    mode: 'history',
    routes: [
        {
            path: '/',
            name: 'home',
            component: () => import('../views/Home.vue'),
        },
        {
            name: '1',
            path: ':id',
            component: () => import('../views/Component1.vue'),
            children: [
                {
                    path: '/1-1',
                    name: '1-1',
                    component: () => import('../views/Component1-1.vue'),
                },
                {
                    path: '/1-2',
                    name: '1-2',
                    component: () => import('../views/Component1-1.vue'),
                },
                {
                    path: '/1-3',
                    name: '1-3',
                    component: () => import('../views/Component1-1.vue'),
                },
            ],
        },
    ],
});