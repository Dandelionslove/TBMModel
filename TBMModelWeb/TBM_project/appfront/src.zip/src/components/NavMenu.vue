<template>
<div class="container">
    <el-row class="container">
        <el-col :span="24" class="container">
            <el-menu :router=true :default-active="$route.name" class="el-menu-vertical-demo container">
                <el-submenu index="1">
                    <template slot="title">
                        <span>title1</span>
                    </template>
                    <el-menu-item index="1-1">title1-1</el-menu-item>
                    <el-menu-item index="1-2">title1-2</el-menu-item>
                    <el-menu-item index="1-3">title1-3</el-menu-item>
                </el-submenu>
            </el-menu>
        </el-col>
    </el-row>
</div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class NavMenu extends Vue {}
</script>
