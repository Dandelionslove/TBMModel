import Vue from 'vue'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
// import App from './App.vue'
// import Menu from './menu.vue'
import VueRouter from 'vue-router'
import routes from './router/router.ts'
// import SurroundingRock from './surrounding-rock.vue'
// import DrivingParam from './driving-param.vue'
// import Component1 from './Component1.vue'
// Vue.use(ElementUI)
Vue.use(VueRouter);
// Vue.config.productionTip = false;

const router = new VueRouter({ routes });
// new Vue({
//   el: '#app',
//   // router,
//   render: h => h(App)
// })

// new Vue({
//   el: '#menu',
//   // router,
//   render: h => h(Menu)
// })

// new Vue({
//   el: '#SurroundingRock',
//   // router,
//   render: h => h(SurroundingRock)
// })

// new Vue({
//   el: '#DrivingParam',
//   // router,
//   render: h => h(DrivingParam)
// })

