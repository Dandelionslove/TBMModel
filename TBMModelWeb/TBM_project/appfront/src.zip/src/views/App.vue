<template>
<div id="app">
    <el-container class="container" >

        <el-container class="container">
            <el-aside class="aside">
                <NavMenu/>
            </el-aside>

            <el-main class="main">
                <router-view/>
            </el-main>
        </el-container>
    </el-container>
</div>
</template>

<script lang="ts">
import Vue from 'vue';
import { Provide, Component } from 'vue-property-decorator';
import NavMenu from '../components/NavMenu.vue';

@Component({
  components: {
    NavMenu,
  },
})
export default class App extends Vue {}
</script>

<style lang="less">
* {
    padding: 0;
    margin: 0;
}
html,
body {
    height: 100%;
}

#app {
    height: 100%;
}

.container {
    height: 100%;
}

.aside {
    height: 100%;
    width: 15%;
    min-width: 200px;
    max-width: 240px;
}
</style>
